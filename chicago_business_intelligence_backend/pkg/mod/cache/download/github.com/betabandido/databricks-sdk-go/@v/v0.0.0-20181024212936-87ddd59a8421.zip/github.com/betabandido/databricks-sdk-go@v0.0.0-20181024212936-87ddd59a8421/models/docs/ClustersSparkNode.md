# ClustersSparkNode

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PrivateIp** | **string** |  | [optional] [default to null]
**PublicDns** | **string** |  | [optional] [default to null]
**NodeId** | **string** |  | [optional] [default to null]
**InstanceId** | **string** |  | [optional] [default to null]
**StartTimestamp** | **int64** |  | [optional] [default to null]
**HostPrivateIp** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


