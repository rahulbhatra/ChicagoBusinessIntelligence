# WorkspaceImportRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Path** | **string** |  | [default to null]
**Format** | [***WorkspaceExportFormat**](WorkspaceExportFormat.md) |  | [optional] [default to null]
**Language** | [***WorkspaceLanguage**](WorkspaceLanguage.md) |  | [optional] [default to null]
**Content** | **string** |  | [optional] [default to null]
**Overwrite** | **bool** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


