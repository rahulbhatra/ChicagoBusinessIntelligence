# GroupsRemoveMemberRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserName** | **string** |  | [optional] [default to null]
**GroupName** | **string** |  | [optional] [default to null]
**ParentName** | **string** |  | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


