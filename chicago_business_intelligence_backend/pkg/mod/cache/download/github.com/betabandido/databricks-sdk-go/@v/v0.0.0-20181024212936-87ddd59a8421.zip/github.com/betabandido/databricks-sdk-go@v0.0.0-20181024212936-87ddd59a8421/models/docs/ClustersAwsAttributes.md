# ClustersAwsAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstOnDemand** | **int32** |  | [optional] [default to null]
**Availability** | [***ClustersAwsAvailability**](ClustersAwsAvailability.md) |  | [optional] [default to null]
**ZoneId** | **string** |  | [optional] [default to null]
**InstanceProfileArn** | **string** |  | [optional] [default to null]
**SpotBidPricePercent** | **int32** |  | [optional] [default to null]
**EbsVolumeType** | [***ClustersEbsVolumeType**](ClustersEbsVolumeType.md) |  | [optional] [default to null]
**EbsVolumeCount** | **int32** |  | [optional] [default to null]
**EbsVolumeSize** | **int32** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


