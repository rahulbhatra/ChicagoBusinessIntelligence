package models

type SparkNodeAwsAttributes struct {
	IsSpot bool `json:"is_spot,omitempty" url:"is_spot,omitempty"`
}
