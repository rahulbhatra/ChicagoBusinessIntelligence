package models

type ListOrder string

const (
	ListOrderDesc = "DESC"
	ListOrderAsc  = "ASC"
)
