package models

type SparkSubmitTask struct {
	Parameters *[]string `json:"parameters,omitempty" url:"parameters,omitempty"`
}
