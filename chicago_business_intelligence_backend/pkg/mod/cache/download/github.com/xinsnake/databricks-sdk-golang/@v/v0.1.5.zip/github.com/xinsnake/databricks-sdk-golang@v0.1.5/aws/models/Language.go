package models

type Language string

const (
	LanguageScala  = "SCALA"
	LanguagePython = "PYTHON"
	LanguageSQL    = "SQL"
	LanguageR      = "R"
)
