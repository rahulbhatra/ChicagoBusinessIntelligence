package databricks

const (
	// APIVersion is the version of the RESTful API of DataBricks
	APIVersion = "2.0"
	// SdkVersion is the version of this library
	SdkVersion = "0.1.3"
)
