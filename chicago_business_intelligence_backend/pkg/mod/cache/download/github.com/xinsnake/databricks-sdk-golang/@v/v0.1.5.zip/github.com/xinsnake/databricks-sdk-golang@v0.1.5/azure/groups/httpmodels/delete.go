package httpmodels

type DeleteReq struct {
	GroupName string `json:"group_name,omitempty" url:"group_name,omitempty"`
}
