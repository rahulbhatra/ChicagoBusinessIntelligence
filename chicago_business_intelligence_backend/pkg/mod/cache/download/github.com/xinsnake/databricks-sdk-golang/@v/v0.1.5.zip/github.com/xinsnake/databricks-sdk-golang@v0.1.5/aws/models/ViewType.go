package models

type ViewType string

const (
	ViewTypeNotebook  = "NOTEBOOK"
	ViewTypeDashboard = "DASHBOARD"
)
