package models

type DiskType struct {
	AzureDiskVolumeType AzureDiskVolumeType `json:"azure_disk_volume_type,omitempty" url:"azure_disk_volume_type,omitempty"`
}
