package models

type ViewsToExport string

const (
	ViewsToExportCode       = "CODE"
	ViewsToExportDashboards = "DASHBOARDS"
	ViewsToExportAll        = "ALL"
)
