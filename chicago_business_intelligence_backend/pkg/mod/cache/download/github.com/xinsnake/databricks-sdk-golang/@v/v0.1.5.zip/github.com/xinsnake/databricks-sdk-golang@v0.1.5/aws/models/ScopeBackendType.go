package models

type ScopeBackendType string

const (
	ScopeBackendTypeDatabricks = "DATABRICKS"
)
