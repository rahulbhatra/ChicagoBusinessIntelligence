package models

type InstancePoolState string

const (
	InstancePoolStateActive  = "ACTIVE"
	InstancePoolStateDeleted = "DELETED"
)
