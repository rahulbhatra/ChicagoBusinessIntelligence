package models

type EbsVolumeType string

const (
	EbsVolumeTypeGeneralPurposeSsd      = "GENERAL_PURPOSE_SSD"
	EbsVolumeTypeThroughputOptimizedHdd = "THROUGHPUT_OPTIMIZED_HDD"
)
