package models

type ClusterSource string

const (
	ClusterSourceUI  = "UI"
	ClusterSourceJob = "JOB"
	ClusterSourceAPI = "API"
)
